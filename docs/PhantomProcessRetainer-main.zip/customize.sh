ui_print " "
ui_print " "
MVERSION=`grep_prop version $MODPATH/module.prop`
MVERSIONCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " > ID = $MODID"
ui_print " > Version = $MVERSION"
ui_print " > VersionCode = $MVERSIONCODE"
ui_print " > MagiskVersion = $MAGISK_VER"
ui_print " > MagiskVersionCode = $MAGISK_VER_CODE"
ui_print " "
ui_print " > Device SDK = $API"

MIN=31

if [ "$API" -lt $MIN ]; then
  ui_print " "
  ui_print "   Your device is NOT Running Android 12+"
  ui_print "   Phantom Process Killer isn't available on your Android Version."
  abort
else
  ui_print " "
  ui_print "   👻 Now the Ghost Busters might be Sleeping..."
  ui_print " "
fi